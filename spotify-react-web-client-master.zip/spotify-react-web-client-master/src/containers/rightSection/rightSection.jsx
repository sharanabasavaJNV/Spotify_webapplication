import React from 'react';

import './rightSection.css';

const rightSection = props => (
  <div className="right-section">
    <div className="header">
      <h4>Friends Activity</h4>
    </div>
  </div>
);

export default rightSection;
